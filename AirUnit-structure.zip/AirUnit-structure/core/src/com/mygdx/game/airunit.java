package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.*;
import com.badlogic.gdx.graphics.g2d.freetype.FreeTypeFontGenerator;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.sun.javafx.scene.control.TableColumnSortTypeWrapper;

public class airunit extends ApplicationAdapter implements InputProcessor{
	SpriteBatch batch;
	Texture img, star, star2;
	TextureRegion backgroundTexture;
	OrthographicCamera camera;
	Vector3 mouse_position = new Vector3(0,0,0);
	float pos_x;
	float rotate_x, mX=0;
	float rotate_y, angle = 0;
	float distance=100, alpha=0;
	int update_position = 0;
	private Sprite sprite;


	private int panning;

	@Override
	public void create () {

		batch = new SpriteBatch(10);
		img = new Texture("orbit.png");
		star = new Texture("star.png");
		star2 = new Texture("star2.png");
		backgroundTexture = new TextureRegion(new Texture("origin.jpg"), 0, 0, 4000, 1100);
		camera = new OrthographicCamera(1280, 720);
		camera.setToOrtho(false, Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
        camera.update();Gdx.input.setInputProcessor(this);
        panning = 0;

	}

	@Override
	public void render () {



		 Gdx.gl.glClearColor(0, 0, 0, 1);
	     Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		// 1000,550
	    mouse_position.set(Gdx.input.getX(), Gdx.input.getY(), 0);

		camera.unproject(mouse_position.set(Gdx.input.getX(),Gdx.input.getY(), 0));
		System.out.println(mouse_position);
		batch.setProjectionMatrix(camera.combined);
		switch(panning){
		case 1:
			if(camera.position.x>750){
				camera.translate(-10, 0);
				break;}
			break;
		case 2:
			if(camera.position.x<2000){
				camera.translate(10, 0);
				break;}
			break;
		}
		camera.update();

		rotate_x = (float) (Math.cos(alpha*MathUtils.degreesToRadians)*distance*2.5);
		rotate_y = (float) (Math.sin(alpha*MathUtils.degreesToRadians)*distance*2.5);
		alpha++;


		batch.begin();
		//batch.draw(backgroundTexture, 0, 0);
		batch.draw(backgroundTexture,0,0,Gdx.graphics.getWidth()*2, Gdx.graphics.getHeight());
		batch.draw(img, 300+rotate_x, 350+rotate_y);
		batch.draw(star,250,300);

		batch.draw(img, 2300+rotate_x, 350+rotate_y);
		batch.draw(star2,2200,300);
		//sprite.draw(batch);
		batch.end();
	}

	
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
	}

	@Override
	public boolean keyDown(int keycode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean keyUp(int keycode) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean keyTyped(char character) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean mouseMoved(int screenX, int screenY) {
		if(screenX < 50 ){
			panning = 1;
		}
		else if(screenX > 1400 ){
			panning = 2;
		}
		else{
			panning = 0;
		}
		return false;
	}

	@Override
	public boolean scrolled(int amount) {
		// TODO Auto-generated method stub
		return false;
	}
}
