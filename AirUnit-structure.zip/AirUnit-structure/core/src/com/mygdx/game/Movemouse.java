package com.mygdx.game;

public abstract class Movemouse {

}
