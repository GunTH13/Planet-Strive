package com.mygdx.game;

interface Airplane {
	public void HP(int atk, int plus_hp);
	public void ATK(int power);

}
